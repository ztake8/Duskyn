import { ImageWithFallback } from './figma/ImageWithFallback';

export function About() {
  return (
    <section id="about" className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <h2 className="mb-6">About DUSKYN</h2>
            <p className="mb-4 text-gray-600">
              DUSKYN is a premium streetwear manufacturer and global exporter, delivering high-quality menswear 
              to fashion labels and startup brands around the world.
            </p>
            <p className="mb-4 text-gray-600">
              We're not just manufacturers — we're your creative production partners. From design to final dispatch, 
              we handle every step with precision, passion, and purpose.
            </p>
            <p className="text-gray-600">
              Whether you're launching your first collection or scaling your global brand, DUSKYN ensures world-class 
              production quality, startup-friendly flexibility, and zero-delay timelines.
            </p>
          </div>
          <div className="relative h-96 rounded-lg overflow-hidden shadow-xl">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1758270804188-8ca0b6d254bc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwbWFudWZhY3R1cmluZyUyMHRleHRpbGV8ZW58MXx8fHwxNzYyODA2NjgwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Fashion manufacturing"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* What Makes Us Different */}
        <div className="bg-gray-50 rounded-2xl p-8 md:p-10">
          <h2 className="mb-8 text-center">What Makes DUSKYN Different</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-1">
                <div className="w-6 h-6 rounded-full bg-black flex items-center justify-center">
                  <span className="text-white">✓</span>
                </div>
              </div>
              <div>
                <h3 className="mb-1">Design to Delivery</h3>
                <p className="text-gray-600">Complete support from concept to final product</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-1">
                <div className="w-6 h-6 rounded-full bg-black flex items-center justify-center">
                  <span className="text-white">✓</span>
                </div>
              </div>
              <div>
                <h3 className="mb-1">Low MOQ, High Quality</h3>
                <p className="text-gray-600">Perfect for both startups and established labels</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-1">
                <div className="w-6 h-6 rounded-full bg-black flex items-center justify-center">
                  <span className="text-white">✓</span>
                </div>
              </div>
              <div>
                <h3 className="mb-1">No Delays, No Excuses</h3>
                <p className="text-gray-600">We strictly follow production timelines</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-1">
                <div className="w-6 h-6 rounded-full bg-black flex items-center justify-center">
                  <span className="text-white">✓</span>
                </div>
              </div>
              <div>
                <h3 className="mb-1">Regular Updates</h3>
                <p className="text-gray-600">From fabric sourcing to dispatch, we keep you informed</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-1">
                <div className="w-6 h-6 rounded-full bg-black flex items-center justify-center">
                  <span className="text-white">✓</span>
                </div>
              </div>
              <div>
                <h3 className="mb-1">Every Product Quality-Checked</h3>
                <p className="text-gray-600">Each garment passes our strict inspection process</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-1">
                <div className="w-6 h-6 rounded-full bg-black flex items-center justify-center">
                  <span className="text-white">✓</span>
                </div>
              </div>
              <div>
                <h3 className="mb-1">Worldwide Shipping</h3>
                <p className="text-gray-600">Serving brands across the globe</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
