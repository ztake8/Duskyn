import { ImageWithFallback } from './figma/ImageWithFallback';
import { Card } from './ui/card';

export function ProductCategories() {
  const categories = [
    {
      title: 'T-Shirts & Tops',
      items: 'Premium cotton tees, graphic prints, oversized fits',
      image: 'https://images.unsplash.com/photo-1595183948036-e0de97d1c94f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZW5zd2VhciUyMGFwcGFyZWx8ZW58MXx8fHwxNzYyODA2NjgxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      title: 'Hoodies & Sweatshirts',
      items: 'Fleece hoodies, pullover sweatshirts, zip-up styles',
      image: 'https://images.unsplash.com/photo-1511742667815-af572199b23a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHJlZXR3ZWFyJTIwZmFzaGlvbiUyMGNsb3RoaW5nfGVufDF8fHx8MTc2MjgwNjY4MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      title: 'Bottoms',
      items: 'Cargo pants, joggers, denim, straight fit, tapered styles',
      image: 'https://images.unsplash.com/photo-1701964620877-5653b8a7280e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWJyaWMlMjB0ZXh0aWxlJTIwbWF0ZXJpYWx8ZW58MXx8fHwxNzYyNzU1NDY5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      title: 'Co-ord Sets & Outerwear',
      items: 'Matching sets, overshirts, jackets, windbreakers',
      image: 'https://images.unsplash.com/photo-1606053929013-311c13f97b5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbG90aGluZyUyMHByb2R1Y3Rpb24lMjBmYWN0b3J5fGVufDF8fHx8MTc2Mjc3MzgzMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
  ];

  return (
    <section className="py-20 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="mb-4">Product Categories</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We manufacture across all major menswear segments with premium fabrics and finishing
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {categories.map((category, index) => (
            <Card key={index} className="overflow-hidden group hover:shadow-xl transition-shadow">
              <div className="relative h-64 overflow-hidden">
                <ImageWithFallback
                  src={category.image}
                  alt={category.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <h3 className="mb-2">{category.title}</h3>
                  <p className="text-gray-200">{category.items}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
