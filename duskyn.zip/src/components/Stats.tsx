export function Stats() {
  const stats = [
    { number: '100+', label: 'Global Brands Served' },
    { number: '50K+', label: 'Garments Produced Monthly' },
    { number: '25+', label: 'Countries Exported To' },
    { number: '100%', label: 'On-Time Delivery Rate' },
  ];

  return (
    <section className="py-20 px-4 bg-black text-white">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="mb-2">{stat.number}</div>
              <p className="text-gray-400">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
