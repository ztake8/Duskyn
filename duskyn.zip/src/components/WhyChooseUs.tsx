import { ImageWithFallback } from './figma/ImageWithFallback';
import { Palette, TrendingUp, Clock, Tag, RefreshCw, ShieldCheck, Globe, Zap } from 'lucide-react';

export function WhyChooseUs() {
  const benefits = [
    {
      icon: Palette,
      title: 'Expert Designer Team',
      description: 'From concept to collection',
    },
    {
      icon: TrendingUp,
      title: 'Low MOQ',
      description: 'Perfect for startups',
    },
    {
      icon: Clock,
      title: 'Strict Timeline',
      description: 'On-time, every time',
    },
    {
      icon: Tag,
      title: 'Private Label Manufacturing',
      description: 'Build your brand identity',
    },
    {
      icon: RefreshCw,
      title: 'Regular Production Updates',
      description: 'Complete transparency',
    },
    {
      icon: ShieldCheck,
      title: 'Multi-Level Quality Control',
      description: 'Every product inspected',
    },
    {
      icon: Globe,
      title: 'Worldwide Shipping',
      description: 'Global delivery network',
    },
    {
      icon: Zap,
      title: 'End-to-End Solutions',
      description: 'Complete streetwear solutions',
    },
  ];

  return (
    <section id="why-choose-us" className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="mb-4">Why Choose DUSKYN</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Your trusted B2B partner for premium streetwear manufacturing with a commitment 
            to excellence, transparency, and timely delivery.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div key={index} className="flex gap-3 items-start p-5 rounded-lg hover:bg-gray-50 transition-colors border border-gray-200">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-black flex items-center justify-center">
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                </div>
                <div>
                  <h3 className="mb-1">{benefit.title}</h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Work Ethics Section */}
        <div className="bg-black text-white rounded-2xl p-8 md:p-12">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="mb-6">Our Work Ethics</h2>
              <div className="space-y-6">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <Clock className="h-6 w-6" />
                    <h3>Punctuality is Our Promise</h3>
                  </div>
                  <p className="text-gray-300">
                    We work on strict production schedules, ensuring no delays. Every order follows a precise 
                    timeline from start to finish.
                  </p>
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <RefreshCw className="h-6 w-6" />
                    <h3>Transparency is Our Culture</h3>
                  </div>
                  <p className="text-gray-300">
                    You receive regular updates throughout production — from sourcing to final packaging. 
                    Communication and transparency are key pillars of our partnership.
                  </p>
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <ShieldCheck className="h-6 w-6" />
                    <h3>Quality is Our Identity</h3>
                  </div>
                  <p className="text-gray-300">
                    Every product passes intense quality checks before dispatch. We ensure consistency 
                    and perfection in every piece.
                  </p>
                </div>
              </div>
            </div>
            <div className="relative h-80 rounded-lg overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1606053929013-311c13f97b5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbG90aGluZyUyMHByb2R1Y3Rpb24lMjBmYWN0b3J5fGVufDF8fHx8MTc2Mjc3MzgzMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Production facility"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
        
        {/* Commitment Section */}
        <div className="mt-16 text-center max-w-4xl mx-auto">
          <h2 className="mb-6">Our Commitment</h2>
          <p className="text-gray-600 mb-4">
            At DUSKYN, we don't just create garments — we build global streetwear stories.
          </p>
          <p className="text-gray-600">
            Every piece reflects our dedication to design, discipline, and delivery. With a strong foundation 
            in Indian manufacturing excellence and an eye on international fashion, DUSKYN helps brands grow 
            confidently — one collection at a time.
          </p>
        </div>
      </div>
    </section>
  );
}
