import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { MapPin, Phone, Mail } from 'lucide-react';

export function Contact() {
  return (
    <section id="contact" className="py-20 px-4 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="mb-4">Start Your Partnership with DUSKYN</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Ready to bring your fashion brand to life? Get in touch for a quote or consultation.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Contact Information */}
          <div className="space-y-6">
            <Card>
              <CardContent className="flex items-start gap-4 p-6">
                <div className="w-12 h-12 rounded-full bg-black flex items-center justify-center flex-shrink-0">
                  <MapPin className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="mb-2">Manufacturing Hub</h3>
                  <p className="text-gray-600">
                    India<br />
                    (Specific address available upon inquiry)
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex items-start gap-4 p-6">
                <div className="w-12 h-12 rounded-full bg-black flex items-center justify-center flex-shrink-0">
                  <Phone className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="mb-2">Call Us</h3>
                  <p className="text-gray-600">
                    +91 XXX XXX XXXX<br />
                    Available for global inquiries
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex items-start gap-4 p-6">
                <div className="w-12 h-12 rounded-full bg-black flex items-center justify-center flex-shrink-0">
                  <Mail className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="mb-2">Email Us</h3>
                  <p className="text-gray-600">
                    info@duskyn.com<br />
                    sales@duskyn.com
                  </p>
                </div>
              </CardContent>
            </Card>

            <div className="bg-black text-white p-6 rounded-lg">
              <h3 className="mb-3">B2B Inquiries Welcome</h3>
              <p className="text-gray-300 mb-3">
                We work with fashion brands, startups, and established labels worldwide.
              </p>
              <ul className="space-y-2 text-gray-300">
                <li>✓ Private Label Manufacturing</li>
                <li>✓ Low MOQ Available</li>
                <li>✓ Sample Development</li>
                <li>✓ Global Shipping</li>
              </ul>
            </div>
          </div>

          {/* Contact Form */}
          <Card>
            <CardContent className="p-6">
              <form className="space-y-4">
                <div>
                  <Input placeholder="Brand/Company Name" />
                </div>
                <div>
                  <Input placeholder="Your Name" />
                </div>
                <div>
                  <Input type="email" placeholder="Business Email" />
                </div>
                <div>
                  <Input placeholder="Phone Number (with country code)" />
                </div>
                <div>
                  <Textarea placeholder="Tell us about your requirements (product types, quantities, timeline, etc.)" rows={5} />
                </div>
                <Button className="w-full bg-black hover:bg-gray-800">Request Quote</Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
