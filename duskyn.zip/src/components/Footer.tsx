import { Linkedin, Twitter, Facebook, Instagram } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-black text-white py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="mb-4">DUSKYN</h3>
            <p className="text-gray-400 mb-4">
              Premium Streetwear Manufacturer & Global Exporter
            </p>
            <p className="text-gray-400">
              Transforming brand visions into reality with quality and precision.
            </p>
          </div>
          <div>
            <h3 className="mb-4">Services</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#services" className="hover:text-white transition-colors">Private Label</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Low MOQ Production</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Product Development</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Global Shipping</a></li>
            </ul>
          </div>
          <div>
            <h3 className="mb-4">Quick Links</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#about" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#why-choose-us" className="hover:text-white transition-colors">Why Choose Us</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">Get Quote</a></li>
            </ul>
          </div>
          <div>
            <h3 className="mb-4">Connect With Us</h3>
            <div className="flex gap-4 mb-4">
              <a href="#" className="w-10 h-10 rounded-full bg-gray-900 flex items-center justify-center hover:bg-gray-800 transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-900 flex items-center justify-center hover:bg-gray-800 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-900 flex items-center justify-center hover:bg-gray-800 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
            <p className="text-gray-400">
              B2B inquiries welcome<br />
              info@duskyn.com
            </p>
          </div>
        </div>
        <div className="border-t border-gray-900 pt-8 text-center text-gray-400">
          <p className="mb-2">&copy; 2025 DUSKYN. All rights reserved.</p>
          <p className="text-sm">From Design to Dispatch, Crafted with Precision.</p>
        </div>
      </div>
    </footer>
  );
}
