import { Card, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tag, Palette, Lightbulb, Shirt, ShieldCheck } from 'lucide-react';

export function Services() {
  const services = [
    {
      icon: Tag,
      title: 'Private Label Manufacturing',
      description: 'We bring your vision to life through private labeling, handling everything from design, sampling, and branding to packaging — helping you create your own fashion identity.',
    },
    {
      icon: Palette,
      title: 'Expert Designer Team',
      description: 'Our in-house design team understands the pulse of global streetwear. We help you create styles that connect with Gen Z, urban culture, and modern fashion trends — turning your ideas into ready-to-sell collections.',
    },
    {
      icon: Lightbulb,
      title: 'Sampling & Product Development',
      description: 'From fabric selection to fit perfection, every sample is crafted with attention to detail and precision, ensuring you get what you imagined — or better.',
    },
    {
      icon: Shirt,
      title: 'All Menswear Categories',
      description: 'We manufacture T-Shirts, Hoodies, Sweatshirts, Cargo Pants, Joggers, Denim, Co-ord Sets, Overshirts, Jackets, Casuals, Smart Casuals, and Streetwear Essentials.',
    },
    {
      icon: ShieldCheck,
      title: 'Quality Control',
      description: 'Every single product goes through a multi-stage quality inspection — checking fabric, stitching, measurements, and finishing. We make sure every piece shipped under the DUSKYN name stands for perfection and consistency.',
    },
  ];

  return (
    <section id="services" className="py-20 px-4 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="mb-4">Our Expertise</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Complete manufacturing solutions from design to delivery — 
            helping fashion brands create collections that stand out.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow border-2 hover:border-black">
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg bg-black flex items-center justify-center mb-4">
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <CardTitle>{service.title}</CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                </CardHeader>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
