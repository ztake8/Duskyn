
  # duskyn

  This is a code bundle for duskyn. The original project is available at https://www.figma.com/design/KHEHX4FrlTcd2QyhuRY2b3/duskyn.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  